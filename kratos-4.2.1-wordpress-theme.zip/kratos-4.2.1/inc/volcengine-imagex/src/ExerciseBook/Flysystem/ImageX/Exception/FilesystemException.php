<?php


namespace ExerciseBook\Flysystem\ImageX\Exception;


class FilesystemException extends ImageXException
{
}