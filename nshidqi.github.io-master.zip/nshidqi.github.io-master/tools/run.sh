#!/usr/bin/env bash
#
# Run jekyll serve and then launch the site

bundle exec jekyll s -H 0.0.0.0 -l
